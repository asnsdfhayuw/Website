//8 KYU 1
var humanYearsCatYearsDogYears = function(humanYears) {
  let catYears = 0
  let dogYears = 0
  if(humanYears >= 1){
    catYears = 15
    dogYears = 15
    for(let i = 0; i < humanYears - 1; i++){
      if(i == 0){
        catYears += 9
        dogYears += 9
      }else{
        catYears += 4
        dogYears += 5
      }
    }
  }
  
  return [humanYears,catYears,dogYears];
}


//8 KYU 2
function nearestSq(n){
    let nearestLower = 0
    let nearestHigher = 0
    let x = n + 1
    if(Math.floor(Math.sqrt(n)) == Math.sqrt(n)){
      return n   
    }
    for(let i = n; i < x; i++){
      x = i + n
      if(Math.floor(Math.sqrt(i)) == Math.sqrt(i)){
        nearestHigher = i
        i = x + 1
        break;
      }
    }
    for(let i = n; i < x; i --){
      x = i + n
      if(Math.floor(Math.sqrt(i)) == Math.sqrt(i)){
        nearestLower = i
        i = x + 1
        break;
      }
    }
    let diffLower = n - nearestLower
    let diffHigher = nearestHigher - n
    if(diffHigher < diffLower){
      return nearestHigher
    }else{
      return nearestLower
    }
}

//7 KYU 1
function repeats(arr){
    let arr2 = []
    let sum = 0
    for(let i = 0; i < arr.length; i++){
      let occuredTimes = 0
      for(let j = 0; j < arr.length; j++){
        if(arr[i] == arr[j] && i != j){
          OccuredTimes += 1
        }
      }
      if(occuredTimes == 0){
        arr2.push(arr[i])
      }
    }
    for(let i in arr2){
      sum += arr2[i]
    }
    return sum
  };

//7 KYU 2
function triangular( n ) {
    let sum = 0
    if(n <= 0){
      return 0
    }else{
      for(let i = n; i > 0; i--){
        sum += i
      }
    }
    return sum
  }

//6 KYU 1
function mineLocation(field){
    for(let i = 0; i < field.length; i++){
      for(let j = 0; j < field[i].length; j++){
        if(field[i][j] == 1){
          return [j, i]
        }
      }
    }
  }

//6 KYU 2
function digPow(n, p){
    let arrN = ("" + n).split('')
    let sum = 0
    for(let i = 0; i < arrN.length; i ++){
      sum += Math.pow(arrN[i]*1, p)
      p += 1
    }
    if(sum%n == 0){
        return Math.floor(sum/n)
    }else{
        return -1
    }
  }

//6 KYU 3
function backwardsPrime(start, stop){
    let arr = []
    function isPrime(n){
      if(n == 1){
        return false
      }else if(n == 2){
        return true
      }else{
        let divisers = 0
        for(let i = 1; i < n + 1; i ++){
          if(n % i == 0){
            divisers += 1
          }
        }
        if(divisers <= 2){
          return true
        }else{
          return false
        }
      }
    }
      for(let i = start; i < stop; i++){
        let x = i
        x = (((('' + x).split('')).reverse()).join(''))*1
        if(isPrime(x) == true && isPrime(i) == true){
          arr.push(i)
        }
      }
    return arr
}

//5 KYU 2 (Skipped ROT13)
function generateHashtag (str) {
    str = str.split(' ')
    for(let i = 0; i < str.length; i++){
      if(str[i] == ''){
        delete(str[i])
      }
    }
    for(let i = 0; i < str.length; i++){
      if(typeof str[i] == 'string'){
        str[i] = str[i].split('')
        str[i][0] = str[i][0].toUpperCase()
        str[i] = str[i].join('')
      }
    }
    str = str.join('')
    if(str.length >= 140){
      return false
    }
    if(str == ''){
      return false
    }
    return ('#' + str)
}

//5 KYU 3
var variance = function(numbers) {
    let mean = 0
    for(let i = 0; i < numbers.length; i++){
      mean += numbers[i]
    }
    mean /= numbers.length
    let sum = 0
    for(let i = 0; i < numbers.length; i++){
      sum += Math.pow((numbers[i] - mean), 2)
    }
    return sum / numbers.length
  };
  